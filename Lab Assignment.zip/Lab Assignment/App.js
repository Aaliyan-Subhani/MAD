import { StatusBar } from 'expo-status-bar';
import { ImageBackground, StyleSheet, Text, View, TextInput, Button } from 'react-native';

export default function App() {
  return (
    <View style={styles.container}>
      <ImageBackground style={styles.background} source={require("./assets/bg.jpg")}>
        <Text style={styles.txt}>QUARTER</Text>
        <Text style={styles.txt1}>No list. Just the best places to be.</Text>
        <View style={styles.login_container}>
          <TextInput style={styles.input_email} placeholder="  quarter9696@gmail.com" autoCapitalize="none"></TextInput>



        </View>

        <View style={styles.pass_container}>
          <TextInput style={styles.input_pass} placeholder="  Password" autoCapitalize="none"  ></TextInput>
        </View>
        <View style={styles.btn_container}><Button
          fontSize={18}
          width={200}
          lineHeight={20}
          fontWeight="bold"
          textAlign="center"
          backgroundColor="white"
          title="SIGN UP"
        /></View>

      </ImageBackground>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignContent: "center",
    width: 350,
    height: 600,
    borderRadius: 20,
    alignItems: 'center',
    alignSelf: 'center'
  },
  background: {
    width: 350,
    height: 600,
  },
  txt: {
    paddingTop: 90,
    textAlign: "center",
    fontWeight: 'bold',
    fontFamily: 'sansarif',
    fontSize: 40,
    fontStyle: 'normal',
    color: 'white',
  },
  txt1: {
    textAlign: 'center',
    fontWeight: 'bold',
    fontFamily: 'sansarif',
    fontSize: 20,
    fontStyle: 'italic',
    color: "white",
    paddingTop: 10,
  },
  login_container: {
    alignContent: "center",
    alignItems: "center",
    alignSelf: 'center',
    width: 300,
    height: 70,
    paddingTop: 50,
  },
  input_email: {
    width: 200,
    height: 35,
    fontSize: 12,
    borderWidth: 1,
    alignItems: "center",
    borderRadius: 5,
    padding: 10,
  },
  input_pass: {
    width: 200,
    height: 35,
    fontSize: 12,
    borderWidth: 1,
    alignItems: "center",
    borderRadius: 5,
    padding: 10,
  },
  btn_container: {
    alignContent: "center",
    alignItems: "center",
    alignSelf: 'center',
    width: 300,
    height: 200,
    paddingTop: 50,
  },
  pass_container:{
    alignContent: "center",
    alignItems: "center",
    alignSelf: 'center',
    width: 300,
    height: 45,
    paddingTop: 20,
  },
});
